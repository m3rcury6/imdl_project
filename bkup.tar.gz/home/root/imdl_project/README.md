# imdl
wanderbot imdl project, by Kris Gonzalez

This project will run until April 22, "Media Day", where the robot this project is based on will be demonstrated.
