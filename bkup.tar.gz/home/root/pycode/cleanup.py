
print "starting"
import Adafruit_BBIO.GPIO as GPIO
import Adafruit_BBIO.PWM as PWM

GPIO.cleanup()
PWM.cleanup()
print "cleanup complete."
