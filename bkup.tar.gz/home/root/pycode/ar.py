path='/sys/devices/ocp.2/helper.14/AIN'

def read(var):
    # first try, error here
#  f=open(path+str(var))
#  a=f.read()
#  f.close()
    # second try
#  f=open(path+str(var))
#  a=f.read()
#  f.close()
    #third try
#  f=open(path+str(var))
#  a=f.read()
#  f.close()
    # fourth try, NOW it should be updated
  f=open(path+str(var))
  a=f.read()
  f.close()

  a=a[0:len(a)-1]
  return int(a)



