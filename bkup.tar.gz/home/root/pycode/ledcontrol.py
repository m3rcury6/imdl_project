
#objective: turn on any given LED light
import sys

led0='/sys/class/leds/beaglebone:green:usr0/brightness'
led1='/sys/class/leds/beaglebone:green:usr1/brightness'
led2='/sys/class/leds/beaglebone:green:usr2/brightness'
led3='/sys/class/leds/beaglebone:green:usr3/brightness'

leds=[led0,led1,led2,led3]
def ledon(n):
  value = open(leds[n],'w')
  value.write(str(1))
  value.close()

def ledoff(n):
  value = open(leds[n],'w')
  value.write(str(0))
  value.close()


